package com.sqa;

import com.sqa.db.WordTable;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Analyzes the data fed from shakespeareProcessor.
 * <p>
 * TASK 2 starts here.
 */
public class ShakespeareAnalyzerService {

  // Treat this as a global static service
  public static final WordTable database = new WordTable();

  private final ArrayBlockingQueue<String> nonstopWordsQueue = new ArrayBlockingQueue<>(10, true);

  private final AtomicBoolean isRunning = new AtomicBoolean(true);

  public void analyze() {
    while (isRunning.get()) {
      try {
        final String word = nonstopWordsQueue.take();
        System.out.println(word);
        // task 2: do something with the word

      } catch (Exception e) {
        e.printStackTrace();
        break;
      }
    }
  }

  /**
   * Adds the supplied word to a queue to be analyzed.
   * <p>
   * This will throw an exception if the queue is full.
   *
   * @param word The word to add to the analyzer
   */
  public void add(String word) {
    //TODO: remove the line below, and instead, add the item to the nonstopWordsQueue
    System.out.println("Added word: " + word);
  }

  public void start() {
    final Thread thread = new Thread(this::analyze);
    thread.start();
    var stop = new Thread(() -> {
      thread.interrupt();
      isRunning.set(false);
    });
    Runtime.getRuntime().addShutdownHook(stop);
  }

}
