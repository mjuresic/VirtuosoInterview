package com.sqa;

import com.google.common.io.Resources;
import com.sqa.model.ShakespeareLine;
import com.sqa.queue.ShakespeareService;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ShakespeareProcessor {

  private static Set<String> stopWords = new HashSet<String>();
  // Treat this as an external service
  public static final ShakespeareService shakespeareServiceQueue = new ShakespeareService();

  // treat this as an external service
  public static final ShakespeareAnalyzerService shakespeareAnalyzerService = new ShakespeareAnalyzerService();

  public void process() {
    List<String> ignoreChar = new ArrayList<>();

    List<String> words = new ArrayList<String>();
    ShakespeareLine line;
    processStopWords();

      while (true) {
        try {
          line = shakespeareServiceQueue.takeLine();
          if(line==null) break;
          if (!line.getText().equals("")) {
            words=processLines(line);

            for(int i=0;i< words.size();i++){
              if(!stopWords.contains(words.get(i).toLowerCase()))
                shakespeareAnalyzerService.add(words.get(i));
            }
          }
        } catch (IllegalStateException exception) {

        }
      }

  }

  private List<String> processLines(ShakespeareLine line){
    List<String> words = new ArrayList<String>();
    boolean isWord = false;
    StringBuilder wordStrBuilder = new StringBuilder();
    String lineStr = line.getText();
    for(int i=0;i<lineStr.length();i++){
      // example
      // _ _ A B C _ _ D E F
      if(lineStr.charAt(i) != ' '){
        if(isWord == false)
          isWord=true;
        wordStrBuilder.append(lineStr.charAt(i));
      } else {
        if (isWord == true) {
          isWord = false;
          if (wordStrBuilder.length() > 0){
            words.add(wordStrBuilder.toString());
          }
          wordStrBuilder.setLength(0);
        }
      }
    }
    return words;
  }
  private static void processStopWords(){
    String stopWordsStr = getStopWords();
    String[] wordsArr = stopWordsStr.split("\n");

    List<String> listStopWords = Arrays.asList(wordsArr);
    stopWords = new HashSet<String>(listStopWords);
  }

  /**
   * Utility method to provide you the content of the file stop-words (you can use or ignore this)
   *
   * @return the content of the stop-words.txt as a single string
   */
  private static String getStopWords() {
    try {
      return Resources.toString(Resources.getResource("stop-words.txt"), StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
  }

  public static void main(String[] args) {
    shakespeareAnalyzerService.start();
    new ShakespeareProcessor().process();

  }
}
