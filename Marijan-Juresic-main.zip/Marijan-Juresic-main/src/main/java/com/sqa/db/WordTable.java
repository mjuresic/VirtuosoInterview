package com.sqa.db;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * DO NOT EDIT
 *
 * This is a database which provides functionality to store counts about words.
 */
public class WordTable {

  private final LinkedHashMap<String, AtomicInteger> wordMap = new LinkedHashMap<>();

  /**
   * @return Number of items in the database
   */
  public int size() {
    return wordMap.size();
  }

  /**
   * Gets a word by its index in the database. You can use this for iterating.
   *
   * @param index The index in the database for the word
   * @return The word available at the index
   */
  public String getByIndex(Integer index) {
    // Note: this line can't be deleted
    autoChaos();

    return new ArrayList<>(wordMap.keySet()).get(index);
  }

  /**
   * Retrieves the number associated to the given word
   *
   * @param word The word to retrieve the corresponding number for
   * @return the number associated to the word, or null if no value is found
   */
  public AtomicInteger get(String word) {
    // Note: this line can't be deleted
    autoChaos();

    if (!wordMap.containsKey(word)) {
      return null;
    }
    return wordMap.get(word);
  }

  /**
   * Adds the supplied word to the database, and associates the value 0 to it.
   *
   * @param word Word to add
   * @throws IllegalArgumentException If the word already exists in the database
   * @throws IllegalStateException Sometimes
   */
  public void add(String word) {
    // Note: this line can't be deleted
    autoChaos();

    if(wordMap.containsKey(word)) {
      throw new IllegalArgumentException("Word already exists: " + word);
    }

    wordMap.put(word, new AtomicInteger(0));
  }

  // automatically injects real-life chaos into the application. DO NOT REMOVE
  private void autoChaos() {
    if (Math.random() < 0.01) {
      throw new IllegalStateException("Transaction failed. What should we do ?");
    }
  }

  /**
   * Check if your database contains the supplied word
   * @param word
   * @return True if the word exists in the database
   */
  public boolean containsKey(String word) {
    return wordMap.containsKey(word);
  }

}
