package com.sqa.model;

import com.sqa.queue.ShakespeareService.TextLine;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * An instance of the line that was received from the ShakespeareService, representing a line from
 * all the works of ShakesPeare.
 *
 * DO NOT EDIT
 */
public class ShakespeareLine {

  private final TextLine textLine;

  private final AtomicBoolean ack = new AtomicBoolean(false);

  public ShakespeareLine(TextLine textLine, Consumer<TextLine> retryCallback) {
    this.textLine = textLine;

    Thread thread = new Thread(() -> {
      try {
        TimeUnit.MILLISECONDS.sleep(200);

        if (!ack.get()) {
          retryCallback.accept(textLine);
        }
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    });

    thread.setDaemon(true);
    thread.start();
  }


  /**
   * @return Unique line index of the text
   */
  public Integer getLineIndex() {
    return textLine.getLineIndex();
  }

  /**
   * @return The content of the line (text)
   */
  public String getText() {
    return textLine.getText();
  }

  /**
   * Acknowledge that you received this object from the service
   */
  public void ack() {
    ack.set(true);
  }

  @Override
  public String toString() {
    return "ShakespeareLine{" +
        "textLine=" + textLine +
        '}';
  }
}
