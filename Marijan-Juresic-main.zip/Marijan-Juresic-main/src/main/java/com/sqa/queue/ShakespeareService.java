package com.sqa.queue;

import com.sqa.model.ShakespeareLine;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * -- DO NOT EDIT --
 *
 * This service abstracts a third-party service which provides us lines from Shakespeare.
 * <p>
 * Like any distributed service, it may have unexpected failures.
 */
public class ShakespeareService {

  static {
    Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
      e.printStackTrace();
      System.exit(1);
    });
  }

  private static final String SHAKESPEARE_FILE = "/shakespeare.txt";

  private final ArrayBlockingQueue<TextLine> readQueue = new ArrayBlockingQueue<>(10, true);
  private final BufferedReader reader;

  private Long nextFailure;

  public ShakespeareService() {
    InputStream is = this.getClass().getResourceAsStream(SHAKESPEARE_FILE);
    InputStreamReader streamReader = new InputStreamReader(is, StandardCharsets.UTF_8);
    reader = new BufferedReader(streamReader);

    updateNextFailure();
    startFileReader();
  }

  private void startFileReader() {
    final AtomicInteger index = new AtomicInteger(0);

    Thread thread = new Thread(() -> {
      while (true) {
        try {
          TextLine textLine = new TextLine(index.incrementAndGet(), reader.readLine());
          addToQueue(textLine);

          if (Math.random() <= 0.05) {
            addToQueue(textLine);
          }

        } catch (Exception e) {
          throw new RuntimeException("Error reading line.", e);
        }
      }
    });

    thread.setDaemon(true);
    thread.start();
  }

  private void addToQueue(TextLine textLine) {
    try {

      boolean success;

      do {
        success = readQueue.offer(textLine, 1L, TimeUnit.SECONDS);
      } while (!success);

    } catch (InterruptedException e) {
      throw new RuntimeException("Error adding to queue.", e);
    }
  }

  private void updateNextFailure() {
    long now = System.currentTimeMillis();
    // failure will occur between 10 and 20 seconds
    this.nextFailure = now + ((int) (Math.random() * (10)) + 10) * 500;
  }

  /**
   * Reads a single line from the works of Shakespeare.
   *
   * @throws IllegalStateException When the service is temporarily unavailable or some other issue
   *                               occurs
   */
  public synchronized ShakespeareLine takeLine() throws IllegalStateException {
    long now = System.currentTimeMillis();

    try {
      if (now >= nextFailure) {
        updateNextFailure();
        throw new ShakespeareServiceReadException();
      }

      TextLine textLine = readQueue.poll();
      return new ShakespeareLine(textLine, this::addToQueue);

    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }

  public static class TextLine {

    private final Integer lineIndex;
    private final String text;

    public TextLine(Integer lineIndex, String text) {
      this.lineIndex = lineIndex;
      this.text = text;
    }

    /**
     * @return Unique index of the line in the global works of Shakespeare
     */
    public Integer getLineIndex() {
      return lineIndex;
    }

    /**
     * @return The line content (text)
     */
    public String getText() {
      return text;
    }

    @Override
    public String toString() {
      return "TextLine{" +
          "index=" + lineIndex +
          ", text='" + text + '\'' +
          '}';
    }
  }
}
