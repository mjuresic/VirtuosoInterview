package com.sqa.queue;

public class ShakespeareServiceReadException extends Exception {

  public ShakespeareServiceReadException() {
    super(
        "An unexpected error occurred while reading from the shakespeare service, please try again. No data was lost.");
  }
}
