package com.sqa;

import static org.junit.Assert.*;

import org.junit.Test;

public class ShakespeareProcessorTest {

  @Test
  public void processTest() {
    assertTrue(true);
  }
}